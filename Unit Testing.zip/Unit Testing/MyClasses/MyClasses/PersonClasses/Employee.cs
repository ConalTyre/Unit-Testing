﻿namespace MyClasses.PersonClasses
{
    public class Employee : Person
    {
    }
}
