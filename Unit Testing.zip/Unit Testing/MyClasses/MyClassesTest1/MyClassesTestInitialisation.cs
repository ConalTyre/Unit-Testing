﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyClassesTest1
{
    /// <summary>
    /// Summary description for MyClassesTestInitialisation and Clean Up Methods
    /// </summary>
    [TestClass]
    public class MyClassesTestInitialisation
    {
        [AssemblyInitialize]

        public static void AssemblyInitilise(TestContext tc)
        {
            tc.WriteLine("In the Assembly Initialise Method.");
            //TODO: Create resources needed for your tests
        }

        [AssemblyCleanup]
        public static void AssemblyCleanup()
        {
            //TODO: Clean up any resources used by your tests.
        }




        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>


    }
}
