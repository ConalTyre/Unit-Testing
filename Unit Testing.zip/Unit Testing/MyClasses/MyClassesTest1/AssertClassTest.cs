﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MyClasses;
using MyClasses.PersonClasses;

namespace MyClassesTest1
{
    [TestClass]
    public class AssertClassTest
    {
        #region AreEqual/AreNotEqual Tests
        [TestMethod]
        [Owner("Conal")]
        public void AreEqualTest()
        {
            string str1 = "Conal";
            string str2 = "Conal";

            Assert.AreEqual(str1, str2);
        }

        [TestMethod]
        [Owner("ConalT")]
        [ExpectedException(typeof(AssertFailedException))]

        public void AreEqualCaseSensitiveTest()
        {
            string str1 = "Conal";
            string str2 = "conal";

            Assert.AreEqual(str1, str2, false);
        }

        [TestMethod]
        [Owner("Conal")]
        public void AreNotEqualTest()
        {
            string str1 = "Paul";
            string str2 = "John";

            Assert.AreNotEqual(str1, str2);
        }

        [TestMethod]
        [Owner("Conal")]
        public void AreSameTest()
        {
            FileProcess x = new FileProcess();
            FileProcess y = x;

            Assert.AreSame(x, y);
        }

        [TestMethod]
        [Owner("ConalT")]
        public void AreNotSameTest()
        {
            FileProcess x = new FileProcess();
            FileProcess y = x;

            Assert.AreSame(x, y);
        }


        #region IsInstanceOfType Test
        [TestMethod]
        [Owner("Conal")]
        public void IsInstanceOfTypeTest()
        {
            PersonManager mgr = new PersonManager();
            Person per;

            per = mgr.CreatePerson("Paul", "Sherrif", true);

            Assert.IsInstanceOfType(per, typeof(Supervisor));

        }
        #endregion

        #region IsNullTest
        [TestMethod]
        [Owner("Conal")]

        public void ISNullTest()
        {
            PersonManager mgr = new PersonManager();
            Person per;

            per = mgr.CreatePerson("", "Sherrif", true);

            Assert.IsNull(per);
        }
        #endregion



    }
}
#endregion