﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Text.RegularExpressions;

namespace MyClassesTest1
{
    [TestClass]
    public class StringAssertClassTest
    {
        [TestMethod]
        [Owner("Conal")]
        public void ContainsTest()
        {
            string str1 = "John Kuhn";
            string str2 = "Kuhn";

            StringAssert.Contains(str1, str2);
        }

        [TestMethod]
        [Owner("Conal")]
        public void StartsWithTest()
        {
            string str1 = "All Lower Case";
            string str2 = "All Lower Case";

            StringAssert.StartsWith(str1, str2);
        }

        [TestMethod]
        [Owner("Conal")]

        public void IsAllLowerCaseTest()
        {
            Regex r = new Regex(@"^([^A-Z]) + $");

            StringAssert.Matches("all lower case", r);

        }

        [TestMethod]
        [Owner("Conal")]

        public void IsNotAllLowerCaseTest()
        {
            Regex r = new Regex(@"^([^A-Z]) + $");

            StringAssert.DoesNotMatch("All Lower Case", r);


        }
    }
}
