﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MyClasses.PersonClasses;
using System.Collections.Generic;


namespace MyClassesTest1
{
    [TestClass]
    public class CollectionAssertClassTest
    {
        [TestMethod]
        [Owner("ConalT")]
        public void AreCollectionsEqualFailsBecauseNoComparerTest()
        {
            PersonManager mgr = new PersonManager();
            List<Person> peopleExpected = new List<Person>();
            List<Person> peopleActual = new List<Person>();

            peopleExpected.Add(new Person() { FirstName = "Paul", LastName = "Sheffif" });
            peopleExpected.Add(new Person() { FirstName = "John", LastName = "Kuhn" });
            peopleExpected.Add(new Person() { FirstName = "Jim", LastName = "Ruhl" });

            peopleActual = mgr.GetPeople();

            CollectionAssert.AreEqual(peopleExpected, peopleActual);
        }

        [TestMethod]
        [Owner("ConalT")]
        public void AreCollectionsEqualWithComparerTest()
        {
            PersonManager mgr = new PersonManager();
            List<Person> peopleExpected = new List<Person>();
            List<Person> peopleActual = new List<Person>();

            peopleExpected.Add(new Person() { FirstName = "Paul", LastName = "Sheffif" });
            peopleExpected.Add(new Person() { FirstName = "John", LastName = "Kuhn" });
            peopleExpected.Add(new Person() { FirstName = "Jim", LastName = "Ruhl" });

            peopleActual = mgr.GetPeople();

            // Provide your own Comparer to determine eqaulity
            CollectionAssert.AreEqual(peopleExpected, peopleActual, Comparer<Person>.Create((x, y) =>
            x.FirstName == y.FirstName && x.LastName == y.LastName ? 0 : 1));

        }
        [TestMethod]
        [Owner("ConalT")]
        public void AreCollectionEquivalentTest()
        {
            PersonManager mgr = new PersonManager();
            List<Person> peopleExpected = new List<Person>();
            List<Person> peopleActual = new List<Person>();

            //Get Person objects
            peopleActual = mgr.GetPeople();


            //Add Same Person objects to new collection, but in different order

            peopleExpected.Add(peopleActual[1]);
            peopleExpected.Add(peopleActual[2]);
            peopleExpected.Add(peopleActual[0]);

            // Checks for the same objects, but in any order
            CollectionAssert.AreEquivalent(peopleExpected, peopleActual);
        }

        [TestMethod]
        [Owner("Conal")]

        public void IsCollectionOfTypeTest() 
        {
            PersonManager mgr = new PersonManager();
            List<Person> peopleActual = new List<Person>();

            peopleActual = mgr.GetSupervisors();

            CollectionAssert.AllItemsAreInstancesOfType(peopleActual, typeof(Supervisor));
        }




    }
}
